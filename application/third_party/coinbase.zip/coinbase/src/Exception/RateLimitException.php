<?php

namespace Coinbase\Wallet\Exception;

class RateLimitException extends HttpException
{
}
