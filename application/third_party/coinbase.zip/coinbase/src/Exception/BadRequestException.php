<?php

namespace Coinbase\Wallet\Exception;

class BadRequestException extends HttpException
{
}
