<?php

namespace Coinbase\Wallet\Exception;

class InternalServerException extends HttpException
{
}
